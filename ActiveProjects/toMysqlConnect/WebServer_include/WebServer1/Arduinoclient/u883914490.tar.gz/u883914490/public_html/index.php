<!DOCTYPE html>
<html>
<body>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251" />
<h1>arduino recieve</h1>
<style>
   .green1 {
    background: green; /* ����� ���� ���� */
    color: white;
   }
    .grey {
    background: grey; /* ����� ���� ���� */
    color: white;
   }
    .yellow {
    background: yellow; /* ����� ���� ���� */
    color: black;
   }
  </style>
<?php
$db='u883914490_user';
$Passdb='5506487';
$table='pins';

if (!$_GET["indata"]){
$str = "Now data:".$_GET ["indata"]."<br>";

echo $str;
}
else{
echo "<br>";
}
$indata=$_GET["indata"];
$field=$_GET["field"];
$field_data=$_GET["field_data"];


$link = mysql_connect('mysql.hostinger.com.ua', $db, $Passdb)
    or die('�� ������� �����������: ' . mysql_error());
echo '���������� ������� �����������';
mysql_select_db($db) or die('�� ������� ������� ���� ������');

$today = date("Y-m-d H:i:s");
$user_agent = $_SERVER['HTTP_USER_AGENT'];

for ($i=0;$i<10;$i++){
	if (isset($_GET["a_s"][$i])){
	$actual_state=$_GET["a_s"][$i];
		$query_insert_new_actual_state ="UPDATE $table SET actual_state='$actual_state', date='$today',User='$user_agent' WHERE name_pin='".$i."'";
    	echo $query_insert_new_actual_state;
    	mysql_query($query_insert_new_actual_state, $link) or die(mysql_error());

	}

}
	if (isset($_GET["reboot_milis"])){             $reboot_millisec=$_GET["reboot_milis"];

		//$query_select_for_insert_reboot_millisec="SELECT 'reboot_millisec' FROM 'settings'";
		//$result_for_insert_reboot_millisec = mysql_query($query_select_for_insert_reboot_millisec);
		$delete = "DELETE 'reboot_millisec' FROM 'settings'";
		$result_delete = mysql_query($delete);
     //   if (mysql_num_rows($result_for_insert_reboot_millisec)==0){    		$query_insert_new_reboot_millisec ="INSERT INTO settings (reboot_millisec,date) VALUES ('$reboot_millisec','$today')";
    		echo $query_insert_new_reboot_millisec;
    		mysql_query($query_insert_new_reboot_millisec, $link) or die(mysql_error());

    	}

// ��������� SQL-������
$query_select_for_insert="SELECT * FROM $table";
$result_for_insert = mysql_query($query_select_for_insert);

	while ($row = mysql_fetch_assoc($result_for_insert)) {    $name_pin_i=$row['name_pin'];
	$name_pin_change=$_POST['button'][$name_pin_i];
		$new_state= $_POST['state'][$name_pin_i];
		//echo  "state:".$new_state;
	if ($name_pin_change!=""){        if ($new_state==1){$new_state_write=0;}
        if ($new_state==0){$new_state_write=1;}
    	$query_insert_new_state ="UPDATE $table SET state='$new_state_write',User='$user_agent',date='$today' WHERE name_pin='".$name_pin_change."'";
    	//echo $query_insert_new_state;
    	mysql_query($query_insert_new_state, $link) or die(mysql_error());
    }

	}






$query_select="SELECT * FROM $table";
$result = mysql_query($query_select);

if (!$result) {
    $message  = '�������� ������: ' . mysql_error() . "\n";
    $message .= '������ �������: ' . $query;
    die($message);

}
//////////////////////////////////

if (mysql_num_rows($result)<10){
	for ($i=0;$i<10;$i++){
    $query_insert ="INSERT INTO $table VALUES (0,'$i',1,0,0,'$today','$user_agent')";
	mysql_query($query_insert, $link) or die(mysql_error());
	}
}


echo '<BR>Number_fields:'.mysql_num_rows($result).':number';
echo"<form action='index.php' method='post'> <table border='0'>";

$fields = mysql_list_fields($db, $table);
$columns = mysql_num_fields($fields);
echo "<tr>";
for ($i = 0; $i < $columns; $i++) {
$col_name = mysql_field_name($fields, $i) . "\n";
echo "<td>".$col_name."</td>";
}
echo "</tr>";

while ($row = mysql_fetch_assoc($result)) {
echo "<tr>";
	//$name_pin=$row['name_pin'];
    //echo $_POST['button'][$name_pin];
 for ($i1 = 0; $i1 < $columns; $i1++) {
    $col_name = mysql_field_name($fields, $i1);
	echo"<td>";

  	echo "<input type='text' size='10' maxlength='10' name='".$col_name."[".$row['name_pin']."]'  value='".$row[$col_name]."'>";
	//echo "<input type='hidden' value=db".$col_name.$row['name_pin'].":".$row[$col_name].":ve".$col_name.$row['name_pin'];
	echo "<input type='hidden' value='db".$col_name.$row['name_pin'].":".$row[$col_name]."'";


	echo"</td>";
 }
//echo  "<input type='submit' name='button[".$row['name_pin']."]' value='SW:[".$row['name_pin']."]' />";
if (($row['state']!=$row['actual_state'])){$button_class='yellow';}
if (($row['state']==1)&&($row['actual_state']==1)){$button_class='green1';}
if (($row['state']==0)&&($row['actual_state']==0)){$button_class='grey';}
if ($row['in_out']==1){$in_out="IN";};if ($row['in_out']==0){$in_out="OUT";}
echo " <td><button value='".$row['name_pin']."'  class='$button_class_IN_OUT' name='button_IN[".$row['name_pin']."]' >".$in_out."</button></td>";

echo " <td><button value='".$row['name_pin']."'  class='$button_class' name='button[".$row['name_pin']."]' >SW:".$row['name_pin']."</button></td>";
echo "</tr>";
//echo "<tr>";
//echo "<input type='button' value=db".$col_name.$row['name_pin'].":".$row[$col_name].":ve".$col_name.$row['name_pin'];

//echo "</tr>";

}

echo"</table> </form>";

mysql_close($link);
?>



</body>
</html>
