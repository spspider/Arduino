ESP8266Wavspiffs
----------------

Read WAV/RIFF audio files. Parses header and returns properties. This is
mostly designed for uncompressed PCM audio. The WAV files must be stored
in the ESP8266 SPIFFS file system.

I didn't write the code, the original [author](https://github.com/bbx10) used it as part of a cool [project](https://github.com/bbx10/SFX-I2S-web-trigger/). Repackaged
here for convenient reuse.
