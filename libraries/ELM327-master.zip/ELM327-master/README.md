# ELM327
A library to communicate with an ELM327 device via an arduino's serial connection

This makes it easy to use a cheap $5 OBD-II bluetooth adapter with an arduino. Simply remove the bluetooth chip and solder on TX/RX/GND leads. 
