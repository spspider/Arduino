<?php
echo exec('getmac');
?>