document.addEventListener("DOMContentLoaded", load);
var websocketServerLocation = "'ws://' + location.hostname + ':81/', ['arduino']";
var connection;
var IRjson = {};
var code = new Array();
var name = new Array();
//  var ModifiedJson;
function load() {
  document.getElementById("IRcode").value = "";
  second_passed();
  load2();
  //start('ws://' + location.hostname + ':81/', ['arduino']);

}

function load2() {
  try {
    readTextFile("IRButtons.txt", function(text) {
      try {
        IRjson = JSON.parse(text);
        //ModifiedJson=IRjson;
        makeIRList(IRjson);
        //document.getElementById("codelist").innerHTML += IRjson.code[0];
      } catch (e) {

        makeIRList(IRjson);
        document.getElementById("test").innerHTML += "JSON.parse: " + e;

      }
    });
  } catch (e) {

    document.getElementById("test").innerHTML += e;
  }
  if (IRjson = {}) {
    IRjson.code = new Array();
    IRjson.name = new Array();
    //alert("ok")
  };


}

function deleteRow(i) {
  IRjson.code.splice(i, 1);
  IRjson.name.splice(i, 1);
  makeIRList(IRjson);
}

function makeIRList(IRjson) {
  //document.getElementById("table").innerHTML = "<tbody id='body_table'><tbody>";
  var result = "",table_res="";
  table_res="<tr><td>номер</td><td>код</td><td>имя</td><td>удалить</td></tr>"
  if (IRjson) {
    if (IRjson.code) {
      IRjson.name.splice(IRjson.code.length);
      for (i = 0; i < IRjson.code.length; i++) {
        table_res +=
          "<tr id='number'>" +
          "<td id='number'>" + i + "</td>" +
          "<td id='code'>" + IRjson.code[i] + "</td>" +
          "<td id='name'>" + IRjson.name[i] + "</td>" +
          "<td id='del'><button class='form-control' onclick='deleteRow("+i+")'>X</button></td>" +
          "</tr>";
      }
    }
  }

//table_res="<tr><td></td><td><input type='text' id='IRcode' class='form-control'></td><td><input type='text' id='IRcodуName' class='form-control'></td><td></td></tr>";
document.getElementById("table").innerHTML=table_res;
//document.getElementById("codelist").innerHTML = result;
}
   function WaitIR(submit) {
    //currentTime = new Date();
    //time = currentTime.getTime();
    //hours = currentTime.getHours();
    //BrowserMyDate
    //alert(time);
    //document.getElementsById('BrowserMyTime').value = "10:20:00";
    server = "/WaitIR?IR='true'";
    send_request(submit, server);
   }
   function send_request(submit, server) {
    request = new XMLHttpRequest();
    request.open("GET", server, true);
    request.send();
    save_status(submit, request);
   }

   function save_status(submit, request) {
    old_submit = submit.value;
    request.onreadystatechange = function() {
     if (request.readyState != 4) return;
     submit.value = request.responseText;
     setTimeout(function() {
      submit.value = old_submit;
      submit_disabled(false);
     }, 10000);
    }
    submit.value = 'Подождите...';
    submit_disabled(true);
   }




var oReq = createXmlHttpObject();
oReq.addEventListener("IRRecieve", recieveIR, false);
oReq.open();
function recieveIR(evt){
  alert("получены данные:"+evt);
}

function createXmlHttpObject() {
  if (window.XMLHttpRequest) {
    xmlHttp = new XMLHttpRequest();
  } else {
    xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
  }
  return xmlHttp;
}

function readTextFile(file, callback) {
  var xmlHttp = createXmlHttpObject();
  xmlHttp.overrideMimeType("application/json");
  xmlHttp.open("GET", file, true);
  xmlHttp.onreadystatechange = function() {
    if (xmlHttp.readyState === 4 && xmlHttp.status == "200") {
      callback(xmlHttp.responseText);
    }
  }
  xmlHttp.send(null);
}

function AddNewButton() {

  var savedCode = document.getElementById("IRcode").value;
  var NameIR = document.getElementById("IRcodуName").value;



  //IRjson=JSON.stringify(IRjson);

  IRjson["code"].push(savedCode);
  IRjson["name"].push(NameIR);

  makeIRList(IRjson);
  document.getElementById("demo").innerHTML += JSON.stringify(IRjson);
}

function saveCode() {

  IRjson["num"] = IRjson.code.length;

 var json_upload = "IR=" + JSON.stringify(IRjson);
  xmlHttp.open("POST", '/SaveIR', true);
  xmlHttp.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
  xmlHttp.send(json_upload);
  xmlHttp.onloadend = function() {
    document.getElementById("test").innerHTML += JSON.stringify(IRjson);
  };
}

function second_passed() {
  if (connection) {
    document.getElementById("demo").innerHTML = connection.readyState;
  } else {
    document.getElementById("demo").innerHTML = "Not connected";
    //connection = new WebSocket('ws://' + location.hostname + ':81/', ['arduino']);
  }
  setTimeout(second_passed, 5000);
}

function start(websocketServerLocation) {
  connection = new WebSocket(websocketServerLocation);
  connection.onmessage = function(evt) {
    handleMessage(evt.data);
  };
  connection.onclose = function() {
    //try to reconnect in 5 seconds
    setTimeout(function() {
      start(websocketServerLocation)
    }, 5000);
  };
  connection.onopen = function() {
    document.getElementById("IRcode").value = "Connected";
  };
  document.getElementById("demo").innerHTML = connection.readyState;
}

function handleMessage(data) {
  document.getElementById("IRcode").value = data;
}