document.addEventListener("DOMContentLoaded", load);
var id = 0;
var jsonPinSetup = "{}";

function load() {
  //alert("alert"+getParameterByName('id'));
  id = getParameterByName('id');
  readPinsetup();
}
////////pin_setup.txt//////////////////////////////////////
function readPinsetup() {
  var data = {};
  try {
    readTextFile("pin_setup.txt", function(text) {
      try {
        data = JSON.parse(text);
      } catch (e) {
        document.getElementById("test").innerHTML += e;
      }
      jsonPinSetup = data;
    });
  } catch (e) {}
}

function createXmlHttpObject() {
  if (window.XMLHttpRequest) {
    xmlHttp = new XMLHttpRequest();
  } else {
    xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
  }
  return xmlHttp;
}

function readTextFile(file, callback) {
  //var rawFile = new XMLHttpRequest();
  var xmlHttp = createXmlHttpObject();
  xmlHttp.overrideMimeType("application/json");
  xmlHttp.open("GET", file, true);
  xmlHttp.onreadystatechange = function() {
    if (xmlHttp.readyState === 4 && xmlHttp.status == "200") {
      callback(xmlHttp.responseText);
    }
  }
  xmlHttp.send(null);
}
///////////////////////////////////////////////////////////
function getParameterByName(name, url) {
  if (!url) url = window.location.href;
  name = name.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
    results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}
var types = new Array();
var act = new Array();
var act_btn = new Array();

var selected_typeCondition = new Array();
var selected_hour = new Array();
var selected_min = new Array();
var selected_OptionAct = new Array();
var selected_OptionWhich = new Array();
var selected_typeActBtn = new Array();
var selected_typeAct = new Array();
var selected_SignalChange = new Array();
var selected_timerField = new Array();
var selected_timerType = new Array();

var type = new Array();
var times = new Array();
var dates = new Array();
var act_ = new Array();
var actBtn = new Array();
var which = new Array();
var pins_ = new Array();
var signals = new Array();
var actBtn_ = new Array();
var signals_time = new Array();
var signals_time_convInt = new Array();

function AddCondition(btnId) {
  var result_which = "";
  var result_act = "";


  SelectedSave(btnId);

  //////////////////////////////
  var result = "";

  var add_option;
  var add_act;
  var selected = "";


  signals[0] = "положительный";
  signals[1] = "отрицательный";
  signals[2] = "больше:";
  signals[3] = "меньше:";

  types[0] = "нет";
  types[1] = "по достижению времени";
  types[2] = "по уровню";
  types[3] = "таймер";

  act[0] = "нет";
  act[1] = "установить пин";
  act[2] = "нажать кнопку";
  act[3] = "нажать удаленную кнопку";
  act[4] = "отправить Email";


  act_btn[0] = "нет";
  act_btn[1] = "вкл";
  act_btn[2] = "выкл";
  act_btn[3] = "шим";

  signals_time[0] = "сек";
  signals_time[1] = "мин";
  signals_time[2] = "час";

  for (i = 0; i < types.length; i++) {
    add_option += "<option " + selected + " >" + types[i] + "</option>"
  }
  for (i = 0; i < act.length; i++) {
    add_act += "<option " + selected + " >" + act[i] + "</option>"
  }


  result += "<select class='form-control' id='typeCondition" + btnId + "' onchange='typeConditionChange(" + btnId + ");'>" + add_option +
    "</select>";
  result_which += "<select class='form-control' id='typeAct" + btnId + "' onchange='typeActChange(" + btnId + ");'>" + add_act +
    "</select>";

  document.getElementById("firstButton").innerHTML = "<input type='submit' class='btn btn-lg btn-primary btn-block' value='добавить условие:" + (btnId + 1) + "' onclick='AddCondition(" + (btnId + 1) + ");' />";
  document.getElementById("firstButton").innerHTML += "<input type='submit' class='btn btn-lg btn-primary btn-block' value='сохранить' onclick='save(" + btnId + ")' />";

  document.getElementById("table").innerHTML += "<tbody id='body_table'><tbody>";
  document.getElementById("body_table").innerHTML += "<tr id='row_table" + btnId + "'><td id='resultCondition_table" + btnId + "'></td><td id='resultCondition_choised_table" + btnId + "'></td><td id='resultWhich_table" + btnId + "'></td><td id='resultWhich_choised_table" + btnId + "'></td><td id='resultAct_table" + btnId + "'></td></tr>";
  document.getElementById("resultCondition_table" + btnId).innerHTML += "" + result + "";
  document.getElementById("resultCondition_choised_table" + btnId).innerHTML += "<div id='resultCondition_choisedID" + btnId + "'></div>";
  document.getElementById("resultWhich_table" + btnId).innerHTML += result_which;
  document.getElementById("resultWhich_choised_table" + btnId).innerHTML += "<div id='OptionWhich" + btnId + "'></div>";
  document.getElementById("resultAct_table" + btnId).innerHTML += "<div id='OptionAct" + btnId + "'></div>";


  ///////////////////////достаем из переменной и вписываем
  SelectedLoad(btnId);

  ///////////////////////////////////////////////////////
}

function save(btnId) {
  SelectedSave(btnId);


  var jsonStr2 = {};
  var BtnIDArray = new Array();


  for (i = 0; i < (btnId + 1); i++) { //сперва сохраняем весь выбор в переменную
    BtnIDArray[i] = i;
    if (document.getElementById("typeCondition" + i)) {
      selected_typeCondition[i] = document.getElementById("typeCondition" + i).value;
      type[i] = types.indexOf(selected_typeCondition[i]);
      //jsonStr2["type"] =new Array();
    }

    if (document.getElementById("typeAct" + i)) {
      typeAct_ch = document.getElementById("typeAct" + i).value;

      act_[i] = act.indexOf(typeAct_ch);
    }
    if (document.getElementById("typeActBtn" + i)) {
      typeActBtn_ch = document.getElementById("typeActBtn" + i).value;
      actBtn_[i] = act_btn.indexOf(typeActBtn_ch);
    }
    if (document.getElementById("timerType" + i)) {
      timerType_sel = document.getElementById("timerType" + i).value;
      signals_time_convInt[i] = signals_time.indexOf(timerType_sel);
    }
    //document.getElementById("test").innerHTML = "123"+act_;


  }



  //jsonStr2["type"]=type;

  jsonStr2["tID"] = BtnIDArray;
  jsonStr2["type"] = type;
  if (selected_hour != "") {
    jsonStr2["time"] = selected_hour;
  }
  if (selected_timerField != "") {
    jsonStr2["timer"] = selected_timerField;
    jsonStr2["timerType"] = signals_time_convInt;
  }
  jsonStr2["act"] = act_;
  jsonStr2["actBtn"] = pins_;
  jsonStr2["actOn"] = actBtn_;
  /*
  for (var i = 0; i < (btnId + 1); i++) {
    if (selected_hour != "") {
      jsonStr2["time"] = selected_hour;
    }
  }
  */
  /*
    jsonStr2 = {
      "tID": BtnIDArray,
      "type": type,
      "time": selected_hour,
      "date": selected_min,
      "timer": selected_timerField,
      "act": act_,
      "pins": pins_,
      "do": actBtn
    }
  */
  //var jsonString =JSON.stringify(jsonStr2);
  jsonStr2["ID"] = id;
  jsonStr2["Numbers"] = btnId + 1;
  json = JSON.stringify(jsonStr2);
  //document.getElementById("testJSON").innerHTML = JSON.stringify(jsonStr2);
  var jsonPretty = JSON.stringify(JSON.parse(json), null, 2);
  document.getElementById("testJSON").innerHTML = jsonPretty;

  var json_upload = "json_name=" + jsonPretty;
  //json_upload.append("Number", btnId);
  var xmlHttp = createXmlHttpObject();
  xmlHttp.open("POST", '/condition_setup', true);
  xmlHttp.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');

  xmlHttp.send(json_upload);

  xmlHttp.onloadend = function() {
    // done
    //alert(json_upload);
    document.getElementById("testJSON").innerHTML += "<br>" + json_upload;
    // document.getElementById("test").innerHTML += json_upload;
    //location.reload();
  };

}

function typeActBtnChange(btnId) {

  document.getElementById("OptionAct" + btnId).innerHTML = "ok";
  //alert("ok");
  var selected_pin = document.getElementById("typePins" + btnId).value;
  var add_act_btn = "";
  var result_act_btn = "";
  var selected = "";

  document.getElementById("OptionAct" + btnId).innerHTML = "";
  for (i = 0; i < act_btn.length; i++) {
    add_act_btn += "<option " + selected + " >" + act_btn[i] + "</option>"
  }
  result_act_btn += "<select class='form-control' id='typeActBtn" + btnId + "' onchange='typeActChangeBtn(" + btnId + ");'>" + add_act_btn +
    "</select>";
  result_act_btn += "<div id='typeActIfPWM" + btnId + "'></div>";
  document.getElementById("OptionAct" + btnId).innerHTML += result_act_btn;
}

function typeActChangeBtn(btnId) {
  var result = "";
  var choised;
  choised = document.getElementById("typeActBtn" + btnId).value;
  switch (choised) {
    case act_btn[3]: //PWM
      result = "<input class='form-control' id='pwmTypeAct" + btnId + "' type='text' value='' size='1'>";
      break;

  }
  document.getElementById("typeActIfPWM" + btnId).innerHTML = result;
}

function typeActChange(btnId) {

  document.getElementById("OptionWhich" + btnId).innerHTML = "";


  var pins = new Array();
  var result_pins = "";
  var add_pins = "";
  var selected = "";

  var typeActChoised = document.getElementById("typeAct" + btnId).value;
  switch (typeActChoised) {
    case act[1]:
      for (i = 0; i < 15; i++) {
        pins[i] = "" + i + "";
      }
      //document.getElementById("OptionWhich" + btnId).innerHTML += pins;
      for (i = 0; i < pins.length; i++) {
        add_pins += "<option " + selected + " >" + pins[i] + "</option>";
      }
      //document.getElementById("OptionWhich" + btnId).innerHTML += pins+add_pins;
      result_pins += "<select class='form-control' id='typePins" + btnId + "' onchange='typeActBtnChange(" + btnId + ");' >" + add_pins + "</select>";
      if (document.getElementById("OptionWhich" + btnId)) {
        document.getElementById("OptionWhich" + btnId).innerHTML += result_pins;
      }
      break;
    case act[2]: //нажать кнопку
      if (jsonPinSetup) {
        for (i = 0; i < jsonPinSetup.descr.length; i++) {
          add_pins += "<option " + selected + " >" + jsonPinSetup.descr[i] + "</option>";
        }
      }
      result_pins += "<select class='form-control' id='typePins" + btnId + "' onchange='typeActBtnChange(" + btnId + ");' >" + add_pins + "</select>";
      if (document.getElementById("OptionWhich" + btnId)) {
        document.getElementById("OptionWhich" + btnId).innerHTML += result_pins;
      }
      break;
    case act[3]: //нажать удаленную кнопку

      result_pins += "<input class='form-control' id='remoteButton" + btnId + "' type='text' value='' size='100'>";
      if (document.getElementById("OptionWhich" + btnId)) {
        document.getElementById("OptionWhich" + btnId).innerHTML += result_pins;
      }

      break;
  }




}


function typeConditionChange(btnId) {
  document.getElementById("resultCondition_choisedID" + btnId).innerHTML = "";

  var result_srting = "";
  var typeConditionChoised = document.getElementById("typeCondition" + btnId).value;

  switch (typeConditionChoised) {
    case types[1]: // по времени
      if (document.getElementById("times" + (btnId - 1))) {
        var prevTimeSet = document.getElementById("times" + (btnId - 1)).value;
        result_srting += "<input class='form-control' id='times" + btnId + "' type='time' value='" + prevTimeSet + "' size='1'>";
      } else {
        result_srting += "<input class='form-control' id='times" + btnId + "' type='time' value='08:00:00' size='1'>";
      }
      result_srting += "<input class='form-control' id='dates" + btnId + "' type='date' value='00' size='1'>";
      break;
    case types[2]: //по уровню

      var add_signals = "";
      var selected = "";

      for (var i = 0; i < signals.length; i++) {
        add_signals += "<option >" + signals[i] + "</option>";
      }

      result_srting += "<select class='form-control' id='bySignal" + btnId + "' onchange='SignalChange(" + btnId + ");' >" + add_signals + "</select>";
      result_srting += "<div id='inputSignalChange" + btnId + "'></div>";
      break;
    case types[3]: //таймер

      var add_signals = "";
      var selected = "";



      for (var i = 0; i < signals_time.length; i++) {
        add_signals += "<option >" + signals_time[i] + "</option>";
      }
      result_srting += "<input class='form-control' id='timerField" + btnId + "' type='input' size='1'>";
      result_srting += "<select class='form-control' id='timerType" + btnId + "' onchange='timerOnChange(" + btnId + ");' >" + add_signals + "</select>";
      result_srting += "<div id='inputSignalChange" + btnId + "'></div>";
      break;
  }

  document.getElementById("resultCondition_choisedID" + btnId).innerHTML = result_srting;
}

function SignalChange(btnId) {
  var choised = document.getElementById("bySignal" + btnId).value;
  var result_srting = "";
  if ((choised === signals[2]) || (choised === signals[3])) {
    result_srting += "<input class='form-control' id='pwm'" + btnId + "' type='text' value='' size='1'>";
  }
  document.getElementById("inputSignalChange" + btnId).innerHTML = result_srting;
}

function SelectedLoad(btnId) {
  for (i = 0; i < (btnId + 1); i++) { //сперва сохраняем весь выбор в переменную
    if (document.getElementById("timerField" + i)) {
      document.getElementById("timerField" + i).value = selected_timerField[i];
    }
    if (document.getElementById("timerType" + i)) { //timertype
      document.getElementById("timerType" + i).value = selected_timerType[i];
    }
    if (document.getElementById("bySignal" + i)) {
      document.getElementById("bySignal" + i).value = selected_SignalChange[i];
    }
    if (document.getElementById("typeCondition" + i)) {
      document.getElementById("typeCondition" + i).value = selected_typeCondition[i];
    }
    if (document.getElementById("times" + i)) {
      document.getElementById("times" + i).value = selected_hour[i];
    }
    if (document.getElementById("dates" + i)) {
      document.getElementById("dates" + i).value = selected_min[i];
    }
    if (document.getElementById("typeAct" + i)) {
      document.getElementById("typeAct" + i).value = selected_typeAct[i];
    }
    if (document.getElementById("typePins" + i)) {
      document.getElementById("typePins" + i).value = pins_[i];

    }
    if (document.getElementById("typeActBtn" + i)) {
      document.getElementById("typeActBtn" + i).value = selected_typeActBtn[i];
      //actBtn[i] = act_btn.indexOf(selected_typeActBtn[i]);
    }

  }


}

function SelectedSave(btnId) {
  for (i = 0; i < (btnId + 1); i++) { //сперва сохраняем весь выбор в переменную
    if (document.getElementById("timerField" + i)) { //timertype
      selected_timerField[i] = document.getElementById("timerField" + i).value;
    }
    if (document.getElementById("timerType" + i)) { //timertype
      selected_timerType[i] = document.getElementById("timerType" + i).value;
    }
    if (document.getElementById("bySignal" + i)) {
      selected_SignalChange[i] = document.getElementById("bySignal" + i).value;
    }
    if (document.getElementById("typeCondition" + i)) {
      selected_typeCondition[i] = document.getElementById("typeCondition" + i).value;
      type[i] = types.indexOf(selected_typeCondition[i]);
    }
    if (document.getElementById("times" + i)) {
      selected_hour[i] = document.getElementById("times" + i).value;
    }
    if (document.getElementById("dates" + i)) {
      selected_min[i] = document.getElementById("dates" + i).value;
    }
    if (document.getElementById("typeAct" + i)) {
      selected_typeAct[i] = document.getElementById("typeAct" + i).value;
      act_[i] = act.indexOf(selected_typeAct[i]);
    }
    if (document.getElementById("typePins" + i)) {
      pins_[i] = document.getElementById("typePins" + i).value;

    }
    if (document.getElementById("typeActBtn" + i)) {
      selected_typeActBtn[i] = document.getElementById("typeActBtn" + i).value;
      //actBtn[i] = act_btn.indexOf(selected_typeActBtn[i]);
    }

  }
}