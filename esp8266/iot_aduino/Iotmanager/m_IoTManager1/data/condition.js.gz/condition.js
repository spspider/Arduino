document.addEventListener("DOMContentLoaded", load);
var id = 0;

function load() {
  //alert("alert"+getParameterByName('id'));
  id = getParameterByName('id');
}

function getParameterByName(name, url) {
  if (!url) url = window.location.href;
  name = name.replace(/[\[\]]/g, "\\$&");
  var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
    results = regex.exec(url);
  if (!results) return null;
  if (!results[2]) return '';
  return decodeURIComponent(results[2].replace(/\+/g, " "));
}
var types = new Array();
var act = new Array();
var act_btn = new Array();

var selected_typeCondition = new Array();
var selected_hour = new Array();
var selected_min = new Array();
var selected_OptionAct = new Array();
var selected_OptionWhich = new Array();
var selected_typeActBtn = new Array();
var selected_typeAct = new Array();

var type = new Array();
var hour = new Array();
var min = new Array();
var act_ = new Array();
var actBtn = new Array();
var which = new Array();
var pins_ = new Array();

function AddCondition(btnId) {
  var result_which = "";
  var result_act = "";


  SelectedSave(btnId);

  //////////////////////////////
  var result = "";

  var add_option;
  var add_act;
  var selected = "";

  types[0] = "нет";
  types[1] = "по достижению времени";
  types[2] = "по сигналу";

  act[0] = "нет";
  act[1] = "установить пин";
  act[2] = "нажать кнопку";

  act_btn[0] = "нет";
  act_btn[1] = "вкл";
  act_btn[2] = "выкл";
  act_btn[3] = "шим";

  for (i = 0; i < types.length; i++) {
    add_option += "<option " + selected + " >" + types[i] + "</option>"
  }
  for (i = 0; i < act.length; i++) {
    add_act += "<option " + selected + " >" + act[i] + "</option>"
  }


  result += "<select class='form-control' id='typeCondition" + btnId + "' onchange='typeConditionChange(" + btnId + ");'>" + add_option +
    "</select>";
  result_which += "<select class='form-control' id='typeAct" + btnId + "' onchange='typeActChange(" + btnId + ");'>" + add_act +
    "</select>";

  document.getElementById("firstButton").innerHTML = "<input type='submit' class='btn btn-lg btn-primary btn-block' value='добавить условие:" + (btnId + 1) + "' onclick='AddCondition(" + (btnId + 1) + ");' />";
  document.getElementById("firstButton").innerHTML += "<input type='submit' class='btn btn-lg btn-primary btn-block' value='сохранить' onclick='save(" + btnId + ")' />";

  document.getElementById("table").innerHTML += "<tbody id='body_table'><tbody>";
   document.getElementById("body_table").innerHTML += "<tr id='row_table"+btnId+"'><td id='resultCondition_table"+btnId+"'></td><td id='resultCondition_choised_table"+btnId+"'></td><td id='resultWhich_table"+btnId+"'></td><td id='resultWhich_choised_table"+btnId+"'></td><td id='resultAct_table"+btnId+"'></td></tr>";
  document.getElementById("resultCondition_table"+btnId).innerHTML += "" + result + "";
  document.getElementById("resultCondition_choised_table"+btnId).innerHTML += "<div id='resultCondition_choisedID" + btnId + "'></div>";
  document.getElementById("resultWhich_table"+btnId).innerHTML += result_which;
  document.getElementById("resultWhich_choised_table"+btnId).innerHTML += "<div id='OptionWhich" + btnId + "'></div>";
  document.getElementById("resultAct_table"+btnId).innerHTML += "<div id='OptionAct" + btnId + "'></div>";


  ///////////////////////достаем из переменной и вписываем
  SelectedLoad(btnId);

  ///////////////////////////////////////////////////////
}

function save(btnId) {




  for (i = 0; i < (btnId + 1); i++) { //сперва сохраняем весь выбор в переменную
    if (document.getElementById("typeCondition" + i)) {
      selected_typeCondition[i] = document.getElementById("typeCondition" + i).value;
      type[i] = types.indexOf(selected_typeCondition[i]);
    }
    if (document.getElementById("hour" + i)) {
      selected_hour[i] = document.getElementById("hour" + i).value;
    }
    if (document.getElementById("min" + i)) {
      selected_min[i] = document.getElementById("min" + i).value;
    }
    if (document.getElementById("typeAct" + i)) {
      selected_typeActBtn[i] = document.getElementById("typeAct" + i).value;
      act_[i] = act.indexOf(selected_typeActBtn[i]);
    }
    if (document.getElementById("typePins" + i)) {
      pins_[i] = document.getElementById("typePins" + i).value;

    }
    if (document.getElementById("typeActBtn" + i)) {
      selected_typeActBtn[i] = document.getElementById("typeActBtn" + i).value;
      actBtn[i] = act_btn.indexOf(selected_typeActBtn[i]);
    }
  }

  var jsonStr2 = {};
  jsonStr2 = {
      "type": type,
      "hour": selected_hour,
      "min": selected_min,
      "act": act_,
      "pins": pins_,
      "do": actBtn
    }
    //var jsonString =JSON.stringify(jsonStr2);
  jsonStr2["ID"] = id;
  document.getElementById("testJSON").innerHTML = JSON.stringify(jsonStr2);;
}

function typeActBtnChange(btnId) {

  document.getElementById("OptionAct" + btnId).innerHTML = "ok";
  //alert("ok");
  var selected_pin = document.getElementById("typePins" + btnId).value;
  var add_act_btn = "";
  var result_act_btn = "";
  var selected = "";

  document.getElementById("OptionAct" + btnId).innerHTML = "";
  for (i = 0; i < act_btn.length; i++) {
    add_act_btn += "<option " + selected + " >" + act_btn[i] + "</option>"
  }
  result_act_btn += "<select class='form-control' id='typeActBtn" + btnId + "' onchange='typeActChangeBtn(" + btnId + ");'>" + add_act_btn +
    "</select>";
  document.getElementById("OptionAct" + btnId).innerHTML += result_act_btn;
}

function typeActChange(btnId) {

  document.getElementById("OptionWhich" + btnId).innerHTML = "";


  var pins = new Array();
  var result_pins = "";
  var add_pins = "";
  var selected = "";
  for (i = 0; i < 15; i++) {
    pins[i] = "" + i + "";
  }
  //document.getElementById("OptionWhich" + btnId).innerHTML += pins;
  for (i = 0; i < pins.length; i++) {
    add_pins += "<option " + selected + " >" + pins[i] + "</option>";
  }
  var typeActChoised = document.getElementById("typeAct" + btnId).value;
  switch (typeActChoised) {
    case act[1]:
      //document.getElementById("OptionWhich" + btnId).innerHTML += pins+add_pins;
      result_pins += "<select class='form-control' id='typePins" + btnId + "' onchange='typeActBtnChange(" + btnId + ");' >" + add_pins + "</select>";
      if (document.getElementById("OptionWhich" + btnId)) {
        document.getElementById("OptionWhich" + btnId).innerHTML += result_pins;
      }
      break;
  }



}


function typeConditionChange(btnId) {
  document.getElementById("resultCondition_choisedID" + btnId).innerHTML = "";

  var result_srting = "";
  var typeConditionChoised = document.getElementById("typeCondition" + btnId).value;

  switch (typeConditionChoised) {
    case types[1]:
      result_srting += "<input class='form-control' id='hour" + btnId + "' type='text' value='08' size='1'>";
      result_srting += "<input class='form-control' id='min" + btnId + "' type='text' value='00' size='1'>";
      break;
    case types[2]:
      result_srting = "";
      break;
  }

  document.getElementById("resultCondition_choisedID" + btnId).innerHTML += result_srting;
}

function SelectedLoad(btnId) {
  for (i = 0; i < (btnId + 1); i++) { //сперва сохраняем весь выбор в переменную
    if (document.getElementById("typeCondition" + i)) {
      document.getElementById("typeCondition" + i).value = selected_typeCondition[i];
      // type[i] = types.indexOf(selected_typeCondition[i]);
    }
    if (document.getElementById("hour" + i)) {
      document.getElementById("hour" + i).value = selected_hour[i];
    }
    if (document.getElementById("min" + i)) {
      document.getElementById("min" + i).value = selected_min[i];
    }
    if (document.getElementById("typeAct" + i)) {
      document.getElementById("typeAct" + i).value = selected_typeAct[i];
    }
    if (document.getElementById("typePins" + i)) {
      document.getElementById("typePins" + i).value = pins_[i];

    }
    if (document.getElementById("typeActBtn" + i)) {
      document.getElementById("typeActBtn" + i).value = selected_typeActBtn[i];
      //actBtn[i] = act_btn.indexOf(selected_typeActBtn[i]);
    }

  }


}

function SelectedSave(btnId) {
  for (i = 0; i < (btnId + 1); i++) { //сперва сохраняем весь выбор в переменную
    if (document.getElementById("typeCondition" + i)) {
      selected_typeCondition[i] = document.getElementById("typeCondition" + i).value;
      type[i] = types.indexOf(selected_typeCondition[i]);
    }
    if (document.getElementById("hour" + i)) {
      selected_hour[i] = document.getElementById("hour" + i).value;
    }
    if (document.getElementById("min" + i)) {
      selected_min[i] = document.getElementById("min" + i).value;
    }
    if (document.getElementById("typeAct" + i)) {
      selected_typeAct[i] = document.getElementById("typeAct" + i).value;
      act_[i] = act.indexOf(selected_typeAct[i]);
    }
    if (document.getElementById("typePins" + i)) {
      pins_[i] = document.getElementById("typePins" + i).value;

    }
    if (document.getElementById("typeActBtn" + i)) {
      selected_typeActBtn[i] = document.getElementById("typeActBtn" + i).value;
      actBtn[i] = act_btn.indexOf(selected_typeActBtn[i]);
    }

  }
}