document.addEventListener("DOMContentLoaded", load2);
//document.addEventListener("DOMContentLoaded", load2);
//document.addEventListener("DOMContentLoaded", jsonParse_fortest);
//
var inputOption = new Array();
var inputPinmode = new Array();
var inputPage = new Array();
var inputWidjet = new Array();
var inputPin = new Array();
var inputId = new Array();
var description;
//var inputDescr = new Array();
inputPin[0]="no";
inputPin[1]=0;
inputPin[2]=1;
inputPin[3]=2;
inputPin[4]=3;
inputPin[5]=4;
inputPin[6]=5;

inputPin[7]=9;
inputPin[8]=10;

inputPin[9]=12;
inputPin[10]=13;
inputPin[11]=14;
inputPin[12]=15;
inputPin[13]=16;
inputPin[14]=17;

inputPinmode[0] = "in";
inputPinmode[1] = "out";
inputPinmode[2] = "pwm";
inputPinmode[3] = "adc";

inputPage[0] = 'unknown';
inputPage[1] = 'Kitchen';
inputPage[2] = 'Outdoor';

inputWidjet[0] = 'unknown';
inputWidjet[1] = 'toggle';
inputWidjet[2] = 'button';
inputWidjet[3] = 'range';
inputWidjet[4] = 'small-badge';

var one_string_saved = new Array();
var string_page_saved = new Array();
var string_descr_saved = new Array();
var string_widget_saved = new Array();
var string_pin_saved = new Array();
var string_id_saved = new Array();
var string_defaultVal_saved = new Array();
var numberChosed = 0;
var jsonStr2 = {
  "id": ["0", "1", "2", "3", "4", "5", "6", "7"],
  "pin": [10, 5, 0, 17, 2, 15, 12, 13],
  "page": ["Kitchen", "Kitchen", "Kitchen", "Kitchen", "Outdoor", "Kitchen", "Kitchen", "Kitchen"],
  "descr": ["Light-0", "Light-1", "Dimmer", "ADC", "Garden light", "RED", "GREEN", "BLUE"],
  "widget": ["toggle", "toggle", "range", "small-badge", "toggle", "range", "range", "range"]
};
var jsonStr = "{}";
//var xmlHttp = createXmlHttpObject();
//load();
///////////////////////////////////////////////////


////////////////////////////////////////////////////
var openFile = function(event) {
  var input = event.target;
  var reader = new FileReader();
  reader.onload = receivedText;
  reader.readAsText(input.files[0]);
};

function receivedText(e) {
  lines = e.target.result;
  var newArr = JSON.parse(lines);
  set(newArr);
}
////////////////////////////////
function load2() {

  readTextFile("/pin_setup.txt", function(text) {
    var data = JSON.parse(text);
    jsonStr = data;
    makeInputs(jsonStr);
    set(data);

  });

}

function createXmlHttpObject() {
  if (window.XMLHttpRequest) {
    xmlHttp = new XMLHttpRequest();
  } else {
    xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
  }
  return xmlHttp;
}

function readTextFile(file, callback) {
  //var rawFile = new XMLHttpRequest();
  var xmlHttp = createXmlHttpObject();
  xmlHttp.overrideMimeType("application/json");
  xmlHttp.open("GET", file, true);
  xmlHttp.onreadystatechange = function() {
    if (xmlHttp.readyState === 4 && xmlHttp.status == "200") {
      callback(xmlHttp.responseText);
    }
  }
  xmlHttp.send(null);
}
///////////////////////////////////
var Inputs_idValue;

function makeInputs(jsonStr) {

  if (document.getElementById("string_defaultVal0")) {
    //document.getElementById("test").innerHTML += "!!!" + document.getElementById("string_defaultVal0").value + "!!!";
  }

  if (document.getElementById("Inputs_id")) {
    Inputs_idValue = document.getElementById("Inputs_id").value;
  }
  var numberChosed = 0;
  if (document.getElementById("sel1")) {
    numberChosed = document.getElementById("sel1").value;

  } else if (jsonStr.id) {
    numberChosed = jsonStr.id.length;
  }
  saveAllStrings(32);
  set();
  number_buttons = 32;
  var add_option;
  var selected = "";
  for (i = 0; i <= number_buttons; i++) {


    if (i == numberChosed) {
      selected = " selected";
    } else {
      selected = "";
    }


    add_option += "<option" + selected + ">" + i + "</option>"
  }
  document.getElementById("sel1div").innerHTML = "<select class='form-control' id='sel1' onchange='makeInputs();'>" + add_option + "</select>";


}

function set(jsonStr) {



  if (document.getElementById("sel1")) {
    numberChosed = document.getElementById("sel1").value;
    loadAllStrings(numberChosed);
  }

  if (jsonStr) {
    numberChosed = jsonStr.id.length;
  }


  //numberChosed = 8;
  var one_string = "";
  var one_str_pinmode = "";
  var one_string_page = "";
  var one_string_descr = "";
  var one_string_widget = "";
  var one_string_pin = "";
  var one_string_defaultVal = "";
  var one_string_id = "";
  var one_string_href = "";
  numberInputOptions = 2;

  for (var i = 0; i < numberChosed; i++) {
    // var options = "";
    //var optionsPage = "";



    if (jsonStr) {
      //inputPin = jsonStr.pin;
      inputId = jsonStr.id;
      description = jsonStr.descr[i];
      defaultVal = jsonStr.defaultVal[i];
      //inputPinmode=jsonStr.pinmode[i];
    }


    options = makeinOption(inputOption, i);
    if (jsonStr) {
      optionsPage = makeinOption(inputPage, inputPage.indexOf(jsonStr.page[i]));
      optionsWidjet = makeinOption(inputWidjet, inputWidjet.indexOf(jsonStr.widget[i]));
      optionsPinmode = makeinOption(inputPinmode, inputPinmode.indexOf(jsonStr.pinmode[i]));
      optionsPin = makeinOption(inputPin,inputPin.indexOf(jsonStr.pin[i]));
    } else {
      optionsPage = makeinOption(inputPage, inputPage.indexOf(string_page_saved[i]));
      optionsWidjet = makeinOption(inputWidjet, inputWidjet.indexOf(string_widget_saved[i]));
      optionsPinmode = makeinOption(inputPinmode, inputPinmode.indexOf(one_string_saved[i]));
    }
    
    optionsId = makeinOption(inputId, i);
    one_string += "<select class='form-control' id='one_string" + i + "' onchange='makesmth();'>" + optionsPinmode + "</select>";
    one_string_page += "<select class='form-control' id='string_page" + i + "' onchange='makesmth2();'>" + optionsPage + "</select>";
    one_string_descr += "<input type='text' class='form-control' id='string_descr" + i + "' value='" + description + "'>";
    one_string_widget += "<select class='form-control' id='string_widget" + i + "' onchange='makesmth2();'>" + optionsWidjet + "</select>";
    one_string_pin += "<select class='form-control' id='string_pin" + i + "' onchange='makesmth2();'>" + optionsPin + "</select>";
    one_string_defaultVal += "<input type='text' class='form-control' id='string_defaultVal" + i + "'value='" + defaultVal + "'</input>";
    //one_string_id += "<select class='form-control' id='string_id" + i + "' onchange='makesmth2();'>" + optionsId + "</select>";
    one_string_id += "<input type='text' class='form-control' id='string_id" + i + "' value='" + i + "' ></input>";
    one_string_href += "<a href='condition.htm?id=" + i + "'>условие:" + i + "</a><br>";


  }

  document.getElementById("Inputs").innerHTML = one_string + "<br>";
  document.getElementById("Inputs_id").innerHTML = one_string_id + "<br>";
  document.getElementById("Inputs_row_2").innerHTML = one_string_page + "<br>";
  document.getElementById("Inputs_descr").innerHTML = one_string_descr + "<br>";
  document.getElementById("Inputs_widget").innerHTML = one_string_widget + "<br>";
  document.getElementById("Inputs_pin").innerHTML = one_string_pin + "<br>";
  document.getElementById("Inputs_defaultVal").innerHTML = one_string_defaultVal + "<br>";
  document.getElementById("condition").innerHTML = one_string_href;
  //condition

  if (jsonStr) {
    saveAllStrings(numberChosed);
  }

  //document.getElementById("test").innerHTML += "!!!" + string_page_saved + "!!!";

  loadAllStrings(numberChosed);
  //document.getElementById("Inputs_id").value=Inputs_idValue;
}

function saveAllStrings(numberChosed) {
  for (var i = 0; i < numberChosed; i++) {

    if (document.getElementById("one_string" + i)) {
      one_string_saved[i] = document.getElementById("one_string" + i).value;
    } else {
      //one_string_saved[i] = inputOption[1];
    }
    if (document.getElementById("string_page" + i)) {
      string_page_saved[i] = document.getElementById("string_page" + i).value;
    } else {
      //string_page_saved[i] = inputPage[1];
    }
    if (document.getElementById("string_descr" + i)) {
      string_descr_saved[i] = document.getElementById("string_descr" + i).value;
    }
    if (document.getElementById("string_widget" + i)) {
      string_widget_saved[i] = document.getElementById("string_widget" + i).value;
    }
    if (document.getElementById("string_pin" + i)) {
      string_pin_saved[i] = document.getElementById("string_pin" + i).value;
    }
    if (document.getElementById("string_id" + i)) {
      string_id_saved[i] = document.getElementById("string_id" + i).value;
    }
    if (document.getElementById("string_defaultVal" + i)) {
      string_defaultVal_saved[i] = document.getElementById("string_defaultVal" + i).value;
    } else {
      //string_defaultVal_saved[i] = 0;
    }

  }
}

function loadAllStrings(numberChosed) {
  for (var i = 0; i < numberChosed; i++) {
    if (document.getElementById("one_string" + i)) {
      document.getElementById("one_string" + i).value = one_string_saved[i];
    }
    if (document.getElementById("string_page" + i)) {
      document.getElementById("string_page" + i).value = string_page_saved[i];
    }
    if (document.getElementById("string_descr" + i)) {
      document.getElementById("string_descr" + i).value = string_descr_saved[i];
    }
    if (document.getElementById("string_widget" + i)) {
      document.getElementById("string_widget" + i).value = string_widget_saved[i];
    }
    if (document.getElementById("string_pin" + i)) {
      document.getElementById("string_pin" + i).value = string_pin_saved[i];
    }
    if (document.getElementById("string_id" + i)) {
      //document.getElementById("string_id" + i).value = string_id_saved[i];
    }
    if (document.getElementById("string_defaultVal" + i)) {
      // alert("ok");
      document.getElementById("string_defaultVal" + i).value = string_defaultVal_saved[i];
    }
  }
}

function makeinOption(inputOption, choosed) {
  var options = "";
  var i1;
  var selected = "";
  for (i1 = 0; i1 < inputOption.length; i1++) {
    if (i1 === choosed) {
      selected = " selected";
    } else {
      selected = "";
    }
    options += "<option" + selected + ">" + inputOption[i1] + "</option>";
  }
  return options;
}