var connection = new WebSocket('ws://' + location.hostname + ':81/', ['arduino']);
//var sTopic=new Array;

connection.onopen = function() {
  sendHello();
  check_if_alive();

};

function check_if_alive() {
  if ((!connection)) {
    location.reload();
  }
  setTimeout(check_if_alive(), 30000);
}
connection.onerror = function(error) {

  console.log('WebSocket Error ', error);
  document.getElementById("demo").innerHTML += 'WebSocket Error ' + error;
  location.reload();
};

connection.onmessage = function(evt) {


  ParseText(evt.data);

};

function ParseText(in_parsetext) {
  if (in_parsetext) {
    try {
      parsetext = JSON.parse(in_parsetext);
    } catch (e) {
      splitStringConfig(parsetext);
      //splitStringConfig()
      document.getElementById("demo").innerHTML += "//" + e + "//";
      return;

    }
  }
  if (parsetext.sTopic != null) {
    SetNewStatus(parsetext)
  };
  if (parsetext.topic != null) {
    ParseAndCreateButtons(parsetext)
  };
}

function splitStringConfig(StrConfig) {
  var splittedString = StrConfig.split("/");
  if (splittedString[1] == "IoTmanager") {
    for (i = 0; i < StrConfig.length; i++) {
      if (splittedString[i] == null) {
        break;
      }
      document.getElementById("demo").innerHTML += "/" + splittedString[i];
      if (splittedString[i] == "config") {
        break;
      }
    }
  }
}

function sendStatus() {
  var jsonRecieveArrStatus = new Array();
  jsonRecieveArrStatus[0] = '{"sTopic":"/IoTmanager/dev01-kitchen/light0","status":"0"}';
  jsonRecieveArrStatus[1] = '{"sTopic":"/IoTmanager/dev01-kitchen/light1","status":"1"}';
  jsonRecieveArrStatus[2] = '{"sTopic":"/IoTmanager/dev01-kitchen/dim-light","status":"1023"}';
  jsonRecieveArrStatus[3] = '{"sTopic":"/IoTmanager/dev01-kitchen/ADC","status":"30"}';
  jsonRecieveArrStatus[4] = '{"sTopic":"/IoTmanager/dev01-kitchen/light4","status":"0"}';
  jsonRecieveArrStatus[5] = '{"sTopic":"/IoTmanager/dev01-kitchen/red","status":"0"}';
  jsonRecieveArrStatus[6] = '{"sTopic":"/IoTmanager/dev01-kitchen/green","status":"0"}';
  jsonRecieveArrStatus[7] = '{"sTopic":"/IoTmanager/dev01-kitchen/blue","status":"200"}';
  for (i = 0; i < jsonRecieveArrStatus.length; i++) {
    //SetNewStatus(jsonRecieveArrStatus[i]);
    ParseText(jsonRecieveArrStatus[i])
  }
}

function SetClassName(newstatus) {
  var NewclassName = "btn btn-block btn-default";
  if (newstatus == "1") {
    NewclassName = "btn btn-block btn-success";
  } else {
    NewclassName = "btn btn-block btn-default";
  }
  return NewclassName;
}

function setValueName(newstatus) {
  name = "выкл";
  if (newstatus == 1) {
    name = "вкл";
  } else {
    name = "выкл";
  }
  return name;
}

function SetNewStatus(Statusmessage) {
  parsetext = Statusmessage;

  NewStatus = document.getElementById(parsetext.sTopic);
  if (NewStatus == null) {
    return;
  }
  var id = sId[parsetext.sTopic];

  switch (sWidget[id]) {
    case "toggle":
      NewStatus.value = sDescr[id] + " " + setValueName(parsetext.status);
      NewStatus.className = SetClassName(parsetext.status);
      //NewStatus.className ="btn btn-block btn-default";
      break;
    case "range":
      NewStatus.value = parsetext.status;
      textID = sTopic[id] + "/text";
      setHTML(textID, parsetext.status);
      //document.getElementById(textID).innerHTML = parsetext.status;
      break;
    case "small-badge":
      var progress = (parsetext.status * 100 / 1024);
      NewStatus.style = "width:" + progress + "%";
      textID = sTopic[id] + "/text";
      setHTML(textID, parsetext.status);
      // document.getElementById(textID).innerHTML = parsetext.status;
      break;
    case "button":
      NewStatus.value = sDescr[id] + " " + setValueName(parsetext.status);
      NewStatus.className = SetClassName(parsetext.status);
      //NewStatus.className ="btn btn-block btn-default";
      break;
    case deault:
      NewStatus.value = sDescr[id] + " " + "unknown";
  }
  //NewStatus.value=sDescr[id]+" "+parsetext.status; 
  sStatus(id, parsetext.status);
}

function setHTML(ID, value) {
  if (document.getElementById(ID)) {
    document.getElementById(ID).innerHTML = value; //range
  }
}

function sStatus(id, status) {
  sStatus[id] = status;
}

function sendText() {

  var stringConf = "/IoTmanager/dev01-kitchen/config";
  splitStringConfig(stringConf);
  var jsonRecieveArr = new Array();
  // Construct a msg object containing the data the server needs to process the message from the chat client.
  jsonRecieveArr[0] = '{"id":"0","page":"Kitchen","descr":"Light-0","widget":"button","topic":"/IoTmanager/dev01-kitchen/light0","color":"blue"}';
  //document.getElementById("demo").innerHTML += " id:"+JSON.stringify(jsonRecieve);
  jsonRecieveArr[1] = '{"id":"1","page":"Kitchen","descr":"Light-1","widget":"toggle","topic":"/IoTmanager/dev01-kitchen/light1","color":"orange"}';
  jsonRecieveArr[2] = '{"id":"2","page":"Kitchen","descr":"Dimmer","widget":"range","topic":"/IoTmanager/dev01-kitchen/dim-light","style":"range-calm","badge":"badge-assertive","leftIcon":"ion-ios-rainy-outline","rightIcon":"ion-ios-rainy"}';
  jsonRecieveArr[3] = '{"id":"3","page":"Kitchen","descr":"ADC","widget":"small-badge","topic":"/IoTmanager/dev01-kitchen/ADC","badge":"badge-balanced"}';
  jsonRecieveArr[4] = '{"id":"4","page":"Outdoor","descr":"Garden light","widget":"toggle","topic":"/IoTmanager/dev01-kitchen/light4","color":"red"}';
  jsonRecieveArr[5] = '{"id":"5","page":"Kitchen","descr":"RED","widget":"range","topic":"/IoTmanager/dev01-kitchen/red","style":"range-assertive","badge":"badge-assertive"}';
  jsonRecieveArr[6] = '{"id":"6","page":"Kitchen","descr":"GREEN","widget":"range","topic":"/IoTmanager/dev01-kitchen/green","style":"range-balanced","badge":"badge-balanced"}';
  jsonRecieveArr[7] = '{"id":"7","page":"Kitchen","descr":"BLUE","widget":"range","topic":"/IoTmanager/dev01-kitchen/blue","style":"range-calm","badge":"badge-calm"}';
  //ParseAndCreateButtons(jsonRecieveArr[7]);
  //document.getElementById("demo").innerHTML += "//";
  for (i = 0; i < jsonRecieveArr.length; i++) {
    var parsedtext = jsonRecieveArr[i]
      //ParseAndCreateButtons(parsedtext);
    ParseText(parsedtext);
    //ParseAndCreateButtons(jsonRecieveArr[1]);
    //document.getElementById("demo").innerHTML += "//";
  }

  length = jsonRecieveArr.length;
  connectonclick(length);

}

function ParseAndCreateButtons(parsetext) {

  document.getElementById("demo").innerHTML += "</br>";
  sTopic(parsetext.id, parsetext.topic, parsetext.descr);
  sDescr(parsetext.id, parsetext.descr);
  sWidget(parsetext.id, parsetext.widget);
  sId(parsetext.topic, parsetext.id);
  //sTopic[parsetext.id] =parsetext.topic;
  //sId.push(parsetext.id);
  //sDescr.push(parsetext.descr);
  var makeWidjet;

  textID = parsetext.topic + "/text";
  switch (parsetext.widget) {
    case 'toggle':
      makeWidjet = "<input id='" + parsetext.topic + "' class='btn btn-block btn-success' type='button' value='" + parsetext['descr'] + "' onclick='sendNewValue(" + parsetext.id + ");' /></br>";
      break;
    case 'range':
      makeWidjet = parsetext.descr + " <p1 id='" + textID + "'></p1><input id='" + parsetext.topic + "' class='form-control'  type='range' min='0' max='1024' step='1' onchange='sendNewValue(" + parsetext.id + ");'/></br>";
      break;
    case 'small-badge':
      makeWidjet = parsetext.descr + "<div class='progress'><div id='" + parsetext.topic + "' class='progress-bar' role='progressbar' aria-valuenow='0' aria-valuemin='0' aria-valuemax='1024' style='width:100%'><p1 id='" + textID + "'></p1></div></div>";

      break;
    case 'button':
      makeWidjet = "<input id='" + parsetext.topic + "' class='btn btn-block btn-success' type='button' value='" + parsetext['descr'] + "' onmousedown='mouseDownBtn(" + parsetext.id + ",this)' onmouseup='mouseUpBtn(" + parsetext.id + ",this)' /></br>";
      //makeWidjet = "<input id='" + parsetext.topic + "' class='btn btn-block btn-success' type='button' value='" + parsetext['descr'] + "' onmousedown='mouseDownBtn(" + parsetext.id + ")'   /></br>";

      break;
    default:
      makeWidjet = "unknown";
  }

  document.getElementById("demo").innerHTML += makeWidjet;
  //document.getElementById("demo").innerHTML += parsetext.topic;
};

function mouseDownBtn(id, button) {
  //button.setClass
  //alert("ok");
  //button.classList.className('btn btn-block btn btn-danger');
  PreVvalue = parseInt(sStatus[id]);
  sStatus[id] = switchToggle(PreVvalue);
  button.className = ('btn btn-block btn btn-danger');
  sendNewValue(id);
  document.getElementById("test").innerHTML += "1";
}

function mouseUpBtn(id, button) {
  PreVvalue = parseInt(sStatus[id]);
  //NewStatus.className = SetClassName(parsetext.status);
  //PreVvalue = parseInt(sStatus[id]);
  sStatus[id] = switchToggle(PreVvalue);
  if (PreVvalue == 1) {
    button.className = ('btn btn-block btn btn-success');
  }
  if (PreVvalue == 0) {
    button.className = ('btn btn-block btn btn-primary');
  }
  sendNewValue(id);
}

function sTopic(id, topic) {
  sTopic[id] = topic;
}

function sWidget(id, widget) {
  sWidget[id] = widget;
}

function sDescr(id, descr) {
  sDescr[id] = descr;
}

function sId(topic, id) {
  sId[topic] = id;
}

function sendHello() {

  var docDemo = document.getElementById("demo");
  if (docDemo) {
    document.getElementById("demo").innerHTML = "";
  } else {
    alert("не найден demo обьект");
  }
  connection.send("HELLO");

}

function switchToggle(value) {
  switch (value) {
    case 0:
      return 1;
      break;
    case 1:
      return 0;
      break;
    default:
      return 0;
      break;
      //case 1:		value=0; break;
  }
}

function sendNewValue(id) {

  //document.getElementById("demo").innerHTML+=sTopic[id]+"/control";
  topic = sTopic[id] + "/control";
  PreVvalue = parseInt(sStatus[id]);
  NewValue = document.getElementById(sTopic[id]).value;
  //document.getElementById("demo1").innerHTML+=sTopic[id]+NewValue;
  textID = sTopic[id] + "/text";
  if (document.getElementById(textID)) {
    document.getElementById(textID).innerHTML = NewValue
  };
  //document.getElementById("demo1").innerHTML+=text;
  switch (sWidget[id]) {
    case "toggle":
      setvalue = switchToggle(PreVvalue);
      break;
    case "button":
      setvalue = switchToggle(PreVvalue);
      break;
    case "range":
      setvalue = NewValue;
      break;
  }
  //document.getElementById("demo1").innerHTML+=setvalue;

  //JSON.stringify({ x: 5, y: 6 });
  sendJSON = JSON.stringify({
    'topic': topic,
    'newValue': setvalue
  });
  var docDemo1 = document.getElementById("test");
  if (docDemo1) {
    docDemo1.innerHTML += sendJSON;
  }
  connection.send(sendJSON);


}