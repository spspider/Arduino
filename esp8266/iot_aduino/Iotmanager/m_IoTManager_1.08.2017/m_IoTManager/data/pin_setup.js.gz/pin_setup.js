﻿document.addEventListener("DOMContentLoaded", load2);
//document.addEventListener("DOMContentLoaded", load2);
//document.addEventListener("DOMContentLoaded", jsonParse_fortest);
//
var inputOption = new Array();
var inputPinmode = new Array();
var inputPage = new Array();
var inputWidjet = new Array();
var inputPin = new Array();
var inputId = new Array();
var description;
//var inputDescr = new Array();
inputPin[0] = "no";
inputPin[1] = 0;
//inputPin[2] = 1;//txd
inputPin[3] = 2;
//inputPin[4] = 3;//rxd
inputPin[5] = 4;
inputPin[6] = 5;

//inputPin[7] = 9;
inputPin[8] = 10;

inputPin[9] = 12;
inputPin[10] = 13;
inputPin[11] = 14;
inputPin[12] = 15;
inputPin[13] = 16;
inputPin[14] = 17; //adc

inputPinmode[0] = "no pin";
inputPinmode[1] = "in";
inputPinmode[2] = "out";
inputPinmode[3] = "pwm";
inputPinmode[4] = "adc";
inputPinmode[5] = "low_pwm";
inputPinmode[6] = "IR";

inputPage[0] = 'unknown';
inputPage[1] = 'Kitchen';
inputPage[2] = 'Outdoor';

inputWidjet[0] = 'unknown';
inputWidjet[1] = 'toggle';
inputWidjet[2] = 'button';
inputWidjet[3] = 'range';
inputWidjet[4] = 'small-badge';

var one_string_saved = new Array();
var string_page_saved = new Array();
var string_descr_saved = new Array();
var string_widget_saved = new Array();
var string_pin_saved = new Array();
var string_id_saved = new Array();
var string_defaultVal_saved = new Array();
var numberChosed = 0;
var jsonStr2 = {
  "id": ["0", "1", "2", "3", "4", "5", "6", "7"],
  "pin": [10, 5, 0, 17, 2, 15, 12, 13],
  "page": ["Kitchen", "Kitchen", "Kitchen", "Kitchen", "Outdoor", "Kitchen", "Kitchen", "Kitchen"],
  "descr": ["Light-0", "Light-1", "Dimmer", "ADC", "Garden light", "RED", "GREEN", "BLUE"],
  "widget": ["toggle", "toggle", "range", "small-badge", "toggle", "range", "range", "range"]
};
var jsonStr = "{}";
var jsonStrIR = {};
//var xmlHttp = createXmlHttpObject();
//load();
///////////////////////////////////////////////////


////////////////////////////////////////////////////
var openFile = function(event) {
  var input = event.target;
  var reader = new FileReader();
  reader.onload = receivedText;
  reader.readAsText(input.files[0]);
};

function receivedText(e) {
  lines = e.target.result;
  var newArr = JSON.parse(lines);
  set(newArr);
}
////////////////////////////////
function load2() {
  loadIR();
  var data = {};
  try {
    readTextFile("/pin_setup.txt", function(text) {
      try {
        data = JSON.parse(text);
      } catch (e) {
        document.getElementById("test").innerHTML += e;
        //alert(e);
        makeInputs();
        //set();
      }
      jsonStr = data;
      makeInputs(jsonStr);
      set(data);
    });
  } catch (e) {
    //alert(e)
    makeInputs();
    //set();
  }

}

function loadIR() {
  var data = {};
  try {
    readTextFile("/IRButtons.txt", function(text) {
      try {
        data = JSON.parse(text);
      } catch (e) {
        document.getElementById("test").innerHTML += e;
        //alert(e);
        //makeInputs();
        //makeInputsIR();
        //set();
      }
      //document.getElementById("test").innerHTML +=data;
      jsonStrIR = data;
      //makeInputsIR(jsonStrIR);
      //setIR(data);
    });
  } catch (e) {
    //alert(e)
    //makeInputs();
    //set();
  }

}

function createXmlHttpObject() {
  if (window.XMLHttpRequest) {
    xmlHttp = new XMLHttpRequest();
  } else {
    xmlHttp = new ActiveXObject('Microsoft.XMLHTTP');
  }
  return xmlHttp;
}

function readTextFile(file, callback) {
  //var rawFile = new XMLHttpRequest();
  var xmlHttp = createXmlHttpObject();
  xmlHttp.overrideMimeType("application/json");
  xmlHttp.open("GET", file, true);
  xmlHttp.onreadystatechange = function() {
    if (xmlHttp.readyState === 4 && xmlHttp.status == "200") {
      callback(xmlHttp.responseText);
    }
  }
  xmlHttp.send(null);
}
///////////////////////////////////
var Inputs_idValue;

function makeInputs(jsonStr) {

  if (document.getElementById("string_defaultVal0")) {
    //document.getElementById("test").innerHTML += "!!!" + document.getElementById("string_defaultVal0").value + "!!!";
  }

  if (document.getElementById("Inputs_id")) {
    Inputs_idValue = document.getElementById("Inputs_id").value;
  }
  var numberChosed = 0;
  if (document.getElementById("sel1")) {
    numberChosed = document.getElementById("sel1").value;

  } else if (jsonStr) {
    if (jsonStr.id) {
      numberChosed = jsonStr.id.length;
    }

  }


  set();
  //alert(numberChosed);
  number_buttons = 32;
  var add_option;
  var selected = "";
  for (i = 0; i <= number_buttons; i++) {


    if (i == numberChosed) {
      selected = " selected";
    } else {
      selected = "";
    }


    add_option += "<option" + selected + ">" + i + "</option>"
  }
  document.getElementById("sel1div").innerHTML = "<select class='form-control' id='sel1' onchange='makeInputs();'>" + add_option + "</select>";


}

function set(jsonStr) {



  if (document.getElementById("sel1")) {
    numberChosed = document.getElementById("sel1").value;
    //loadAllStrings(numberChosed);
  }

  if (jsonStr) {
    numberChosed = jsonStr.id.length;
  }
  saveAllStrings(numberChosed);

  //numberChosed = 8;
  var one_string = "";
  var one_str_pinmode = "";
  var one_string_page = "";
  var one_string_descr = "";
  var one_string_widget = "";
  var one_string_pin = "";
  var one_string_defaultVal = "";
  var one_string_id = "";
  var one_string_href = "";
  var description = ""
  numberInputOptions = 2;


  var result_table = "";
  for (var i1 = 0; i1 < numberChosed; i1++) {
    btnId = i1;
    result_table += "<tr id='tr" + btnId + "'>" +
      "<td id='Inputs_table" + btnId + "'></td>" +
      "<td id='Inputs_id_table" + btnId + "'></td>" +
      "<td id='Inputs_page_table" + btnId + "'></td>" +
      "<td id='Inputs_descr_table" + btnId + "'></td>" +
      "<td id='Inputs_widget_table" + btnId + "'></td>" +
      "<td id='Inputs_pin_table" + btnId + "'></td>" +
      "<td id='Inputs_defaultVal_table" + btnId + "'></td>" +
      "<td id='condition_table" + btnId + "'></td>" +
      "</tr>";
  }



  document.getElementById("table").innerHTML += "<tbody id='body_table'><tbody>";
  document.getElementById("body_table").innerHTML = result_table;


  for (var i = 0; i < numberChosed; i++) {
    // var options = "";
    //var optionsPage = "";



    if (jsonStr) {
      //inputPin = jsonStr.pin;
      inputId = jsonStr.id;
      description = jsonStr.descr[i];
      defaultVal = jsonStr.defaultVal[i];
      //inputPinmode=jsonStr.pinmode[i];
    } else {
      description = "";
    }
    //document.getElementById("test").innerHTML += "works"+numberChosed;

    options = makeinOption(inputOption, i);
    if (jsonStr) {
      optionsPage = makeinOption(inputPage, inputPage.indexOf(jsonStr.page[i]));
      optionsWidjet = makeinOption(inputWidjet, inputWidjet.indexOf(jsonStr.widget[i]));
      optionsPinmode = makeinOption(inputPinmode, inputPinmode.indexOf(jsonStr.pinmode[i]));
      optionsPin = makeinOption(inputPin, inputPin.indexOf(jsonStr.pin[i]));
    } else {
      optionsPage = makeinOption(inputPage, 1);
      optionsPin = makeinOption(inputPin, 0);
      optionsWidjet = makeinOption(inputWidjet, 0);
      optionsPinmode = makeinOption(inputPinmode, 0);
      defaultVal = 0;
      description = "button:" + i;
    }
    /*
        optionsId = makeinOption(inputId, i);
        one_string += "<select class='form-control' id='one_string" + i + "' onchange='choisedPinmode(" + i + ");'>" + optionsPinmode + "</select>";
        one_string_page += "<select class='form-control' id='string_page" + i + "' onchange='makesmth2();'>" + optionsPage + "</select>";
        one_string_descr += "<input type='text' class='form-control' id='string_descr" + i + "' value='" + description + "'>";
        one_string_widget += "<select class='form-control' id='string_widget" + i + "' onchange='makesmth2();'>" + optionsWidjet + "</select>";
        one_string_pin += "<select class='form-control' id='string_pin" + i + "' onchange='makesmth2();'>" + optionsPin + "</select>";
        one_string_defaultVal += "<input type='text' class='form-control' id='string_defaultVal" + i + "'value='" + defaultVal + "'</input>";
        //one_string_id += "<select class='form-control' id='string_id" + i + "' onchange='makesmth2();'>" + optionsId + "</select>";
        one_string_id += "<input type='text' class='form-control' id='string_id" + i + "' value='" + i + "' ></input>";
        one_string_href += "<a href='condition.htm?id=" + i + "'>условие:" + i + "</a><br>";
    */

    document.getElementById("Inputs_table" + i).innerHTML = "<select class='form-control' id='one_string" + i + "' onchange='choisedPinmode(" + i + ",true);'>" + optionsPinmode + "</select>";
    document.getElementById("Inputs_id_table" + i).innerHTML += "<input type='text' class='form-control' id='string_id" + i + "' value='" + i + "' ></input>";
    document.getElementById("Inputs_page_table" + i).innerHTML += "<select class='form-control' id='string_page" + i + "' onchange='makesmth2();'>" + optionsPage + "</select>";
    document.getElementById("Inputs_descr_table" + i).innerHTML += "<input type='text' class='form-control' id='string_descr" + i + "' value='" + description + "'>";
    document.getElementById("Inputs_widget_table" + i).innerHTML += "<select class='form-control' id='string_widget" + i + "' onchange='makesmth2();'>" + optionsWidjet + "</select>";
    document.getElementById("Inputs_pin_table" + i).innerHTML += "<select class='form-control' id='string_pin" + i + "' onchange='makesmth2();'>" + optionsPin + "</select>";
    document.getElementById("Inputs_defaultVal_table" + i).innerHTML += "<input type='text' class='form-control' id='string_defaultVal" + i + "'value='" + defaultVal + "'</input>";
    document.getElementById("condition_table" + i).innerHTML += "<a href='condition.htm?id=" + i + "'>условие:" + i + "</a><br>";

  }
  /*
    document.getElementById("Inputs").innerHTML = one_string + "<br>";
    document.getElementById("Inputs_id").innerHTML = one_string_id + "<br>";
    document.getElementById("Inputs_row_2").innerHTML = one_string_page + "<br>";
    document.getElementById("Inputs_descr").innerHTML = one_string_descr + "<br>";
    document.getElementById("Inputs_widget").innerHTML = one_string_widget + "<br>";
    document.getElementById("Inputs_pin").innerHTML = one_string_pin + "<br>";
    document.getElementById("Inputs_defaultVal").innerHTML = one_string_defaultVal + "<br>";
    document.getElementById("condition").innerHTML = one_string_href;
    //condition
  */




  for (var i1 = 0; i1 < numberChosed; i1++) {
    btnId = i1;


  }
  document.getElementById("test").innerHTML = "test Ok";
  if (jsonStr) {
    //saveAllStrings(numberChosed);
  }

  loadAllStrings(numberChosed);
  //document.getElementById("test").innerHTML += "!!!" + string_page_saved + "!!!";
  for (var i = 0; i < numberChosed; i++) {
    choisedPinmode(i, false);
  }
  loadAllStrings(numberChosed);
  // loadAllStrings(numberChosed);
  //document.getElementById("Inputs_id").value=Inputs_idValue;
}

function choisedPinmode(i, makeInput) {
  if (document.getElementById("one_string" + i)) {
    if (makeInput) {
      makeInputs();
    }
    choised = document.getElementById("one_string" + i).value;
    switch (choised) {
      case inputPinmode[2]: //out
        if (document.getElementById("string_widget" + i)) {
          document.getElementById("string_widget" + i).value = inputWidjet[1]; //toggle

        }
        break;
      case inputPinmode[3]: //pwm
        setVal("string_widget" + i, inputWidjet[3]); //range
        setDisable("string_widget" + i);
        break;
      case inputPinmode[4]: //adc

        setVal("string_widget" + i, inputWidjet[4]); //small-badge
        setVal("string_pin" + i, inputPin[14]); //17
        setDisable("string_widget" + i);
        setDisable("string_pin" + i);
        break;
      case inputPinmode[5]: //low_pwm
        if (document.getElementById("string_widget" + i)) {
          document.getElementById("string_widget" + i).value = inputWidjet[3]; //range
        }
        break;
      case inputPinmode[6]: //IR
        if (typeof jsonStrIR.name === "undefined") {
          value = "<a class='btn btn-block btn-primary' href='\IR_setup'>Настройка IR</a>";
          setHTML("Inputs_descr_table" + i, value);
        } else {

          descr_new = "<select class='form-control' onchange='selectidIR(" + i + ")' id='string_descr" + i + "'></select>";
          make_string_pin();
          descr_new += "<a href='\IR_setup'>IR</a>";
          setHTML("Inputs_descr_table" + i, descr_new);
          value = makeinOption(jsonStrIR.name, 0);
          setHTML("string_descr" + i, value);
          setVal("string_widget" + i, inputWidjet[2]); //button
          document.getElementById("string_widget" + i).disabled = true;
          document.getElementById("string_defaultVal" + i).disabled = true;
          setDisable("string_id" + i);
          setDisable("string_pin" + i);
          var id_my = new Array();
          for (i1 = 0; i1 < jsonStrIR.name.length; i1++) {
            id_my[i1] = i1;
          }
          value2 = makeinOption(id_my, jsonStrIR.name.indexOf(getVal("string_descr" + i)));
          setHTML("string_pin" + i, value2);
          
          selectidIR(i);
        }
        break;
    }
  }
}

function setDisable(ID) {
  if (document.getElementById(ID)) {
    document.getElementById(ID).disabled = true;
  } else {
    if (document.getElementById("test")) {
      document.getElementById("test").innerHTML = "ERROR disable:" + ID; //range
    }
  }
}

function selectidIR(i) {//сделать выбор изjsonStr.pin в string_descr5
  index = 0;

  if  (jsonStr.pin[i]){
    index=jsonStr.pin[i];
    //alert(index);
    document.getElementById("string_descr" + i).selectedIndex=index;
  }
    index = document.getElementById("string_descr" + i).selectedIndex;
  //document.getElementById("test").innerHTML =index;
  setVal("string_defaultVal" + i, jsonStrIR.code[index]);
  document.getElementById("string_pin" + i).selectedIndex = document.getElementById("string_descr" + i).selectedIndex;


}

function make_string_pin() {
  //getVal("val");
}

function getVal(ID) {
  var value;
  if (document.getElementById(ID)) {
    value = document.getElementById(ID).value; //range
  } else {
    if (document.getElementById("test")) {
      document.getElementById("test").innerHTML = "wrong:" + ID + "value:" + value; //range
    }
  }
  return value;
}

function setVal(ID, value) {
  if (document.getElementById(ID)) {
    document.getElementById(ID).value = value; //range
  }
}

function setHTML(ID, value) {
  if (document.getElementById(ID)) {
    document.getElementById(ID).innerHTML = value; //range
  }
}

function saveAllStrings(numberChosed) {
  //document.getElementById("test").innerHTML += numberChosed + "!!!!!!";
  for (var i = 0; i < numberChosed; i++) {
    if (document.getElementById("string_descr" + i)) {

    }
    //document.getElementById("test").innerHTML += numberChosed+"!!!!!!";
    if (document.getElementById("one_string" + i)) {
      one_string_saved[i] = document.getElementById("one_string" + i).value;
    } else {
      //one_string_saved[i] = inputPinmode[0];
    }
    if (document.getElementById("string_page" + i)) {
      string_page_saved[i] = document.getElementById("string_page" + i).value;
    } else {
      //string_page_saved[i] = inputPage[1];
    }
    if (document.getElementById("string_descr" + i)) {
      if (document.getElementById("string_descr" + i).value === "undefined") {
        //alert("ok");
        return;
      }
      string_descr_saved[i] = document.getElementById("string_descr" + i).value;
      document.getElementById("test").innerHTML = string_descr_saved[i];
    } else {
      //string_descr_saved[i] = "button:" + i;
    }
    if (document.getElementById("string_widget" + i)) {
      string_widget_saved[i] = document.getElementById("string_widget" + i).value;
    } else {
      //string_widget_saved[i] = inputWidjet[2];
    }
    if (document.getElementById("string_pin" + i)) {
      string_pin_saved[i] = document.getElementById("string_pin" + i).value;
    } else {
      // string_pin_saved[i] =inputPin[0];
    }
    if (document.getElementById("string_id" + i)) {
      string_id_saved[i] = document.getElementById("string_id" + i).value;
    }
    if (document.getElementById("string_defaultVal" + i)) {
      string_defaultVal_saved[i] = document.getElementById("string_defaultVal" + i).value;
    } else {
      //string_defaultVal_saved[i] = "0";
    }

  }

}

function loadAllStrings(numberChosed) {
  var ok = true;
  if (ok) {
    for (var i = 0; i < numberChosed; i++) {
      if ((document.getElementById("one_string" + i))) {
        if (one_string_saved[i] === undefined) {
          return;
        }
        //document.getElementById("test").innerHTML +="<br>"+ one_string_saved[i] + "";

        document.getElementById("one_string" + i).value = one_string_saved[i];
      }
      if ((document.getElementById("string_page" + i))) {
        document.getElementById("string_page" + i).value = string_page_saved[i];
      }
      if ((document.getElementById("string_descr" + i))) {
        document.getElementById("string_descr" + i).value = string_descr_saved[i];
      }
      if ((document.getElementById("string_widget" + i))) {
        document.getElementById("string_widget" + i).value = string_widget_saved[i];
      }
      if ((document.getElementById("string_pin" + i))) {
        document.getElementById("string_pin" + i).value = string_pin_saved[i];
      }
      if ((document.getElementById("string_id" + i))) {
        //document.getElementById("string_id" + i).value = string_id_saved[i];
      }
      if ((document.getElementById("string_defaultVal" + i))) {
        // alert("ok");
        document.getElementById("string_defaultVal" + i).value = string_defaultVal_saved[i];
      }
    }
  }
}

function makeinOption(inputOption, choosed) {
  var options = "";
  var i1;
  var selected = "";
  for (i1 = 0; i1 < inputOption.length; i1++) {
    if (i1 === choosed) {
      selected = " selected";
    } else {
      selected = "";
    }
    options += "<option" + selected + ">" + inputOption[i1] + "</option>";
  }
  return options;
}