# ESP8266-Google-Calendar-Arduino
Interaction between an ESP8266 and the Google Calendar.

Instructions:
Add the googlescript to your google account, set your calendar and publish it.

Copy the id and paste it in the arduino file.

Set your wifi settings.

If you add a new entry to your google calendar - for example an event with the title 7 - then pin 7 will switch on.

*The code is not the nicest - but it works :)
